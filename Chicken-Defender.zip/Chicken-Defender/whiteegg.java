import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class whiteegg extends egg
{
    public whiteegg()
    {
        getImage().scale(50, 50);
    }
    
    public void act() 
    {
        loop();
    }    
}
