import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Spiderblue extends Spider
{
    public Spiderblue()
    {
        leben = 100;
        setup();
        speed = 3;
    }
    
    public void act() 
    {
        loop();
    }    
}
