import greenfoot.*;

public class greenegg extends egg
{
    public greenegg()
    {
        getImage().scale(50, 50);
    }
    
    public void act() 
    {
        loop();
    }    
}
