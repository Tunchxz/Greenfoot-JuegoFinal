import greenfoot.*;

public class Spiderpink extends Spider
{
    public Spiderpink()
    {
        leben = 200;
        setup();
        speed = 2;
    }
    
    public void act() 
    {
        loop();
    }     
}
