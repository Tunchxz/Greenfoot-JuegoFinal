import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class redegg extends egg
{
    public redegg()
    {
        getImage().scale(50, 50);
    }
    
    public void act() 
    {
        loop();
    }    
}
