import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Endgood extends Actor
{
    public void Endgood()
    {
        getImage().scale(800, 550);
    } 
}
