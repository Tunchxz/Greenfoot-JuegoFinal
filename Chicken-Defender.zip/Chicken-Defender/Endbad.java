import greenfoot.*; 

public class Endbad extends Actor
{
    public void Endbad()
    {
        getImage().scale(800, 550);
    } 
}
