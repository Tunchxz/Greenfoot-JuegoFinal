import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Spiderblack extends Spider
{
    public Spiderblack()
    {
        leben = 100;
        setup();
        speed = 1;
    }
    
    public void act() 
    {
        loop();
    }    
}
