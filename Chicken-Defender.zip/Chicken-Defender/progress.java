import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class progress extends Actor
{
    public progress()
    {
        getImage().scale(1, 25);
    }
    
    public void act() 
    {
        // Add your action code here.
    }    
}
