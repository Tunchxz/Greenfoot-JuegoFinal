import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class cooldown extends Actor
{
    public cooldown()
    {
        GreenfootImage image = getImage();
        image.scale(7, 70);
        image.clear();
        image.setColor(Color.BLACK);
        setRotation(180);
    }
}
